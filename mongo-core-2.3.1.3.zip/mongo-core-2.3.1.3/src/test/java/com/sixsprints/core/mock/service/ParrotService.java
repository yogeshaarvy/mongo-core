package com.sixsprints.core.mock.service;

import com.sixsprints.core.mock.domain.inheritance.Parrot;

public interface ParrotService extends GenericAnimalService<Parrot> {

}
