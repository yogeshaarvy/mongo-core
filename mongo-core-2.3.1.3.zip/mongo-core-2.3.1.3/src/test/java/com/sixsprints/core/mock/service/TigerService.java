package com.sixsprints.core.mock.service;

import com.sixsprints.core.mock.domain.inheritance.Tiger;

public interface TigerService extends GenericAnimalService<Tiger> {

}
