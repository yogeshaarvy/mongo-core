package com.sixsprints.core.mock.enums;

public enum Gender {

  MALE, FEMALE, OTHER;

}
