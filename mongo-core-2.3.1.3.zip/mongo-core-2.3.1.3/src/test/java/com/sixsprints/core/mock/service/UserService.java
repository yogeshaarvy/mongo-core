package com.sixsprints.core.mock.service;

import com.sixsprints.core.mock.domain.User;
import com.sixsprints.core.service.GenericCrudService;

public interface UserService extends GenericCrudService<User> {

}
