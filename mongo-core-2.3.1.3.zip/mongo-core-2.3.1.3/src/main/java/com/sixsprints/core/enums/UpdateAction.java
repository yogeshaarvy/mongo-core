package com.sixsprints.core.enums;

public enum UpdateAction {

  UPDATE, CREATE, INVALID, IGNORE;

}
