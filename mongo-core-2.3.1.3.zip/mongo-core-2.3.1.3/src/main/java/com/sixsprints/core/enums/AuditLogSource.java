package com.sixsprints.core.enums;

public enum AuditLogSource {

  BULK_IMPORT, SCREEN;

}
