package com.sixsprints.core.enums;

public enum AuditLogAction {

  CREATE, UPDATE, DELETE, IMPORT, LOGIN, LOGOUT;

}
